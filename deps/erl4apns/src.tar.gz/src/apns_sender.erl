%% @author Administrator
%% @doc @todo Add description to apns_sender.


-module(apns_sender).
-behaviour(gen_server).
-include("localized.hrl").

-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2, code_change/3]).

-define(APNS_POOL,apns_pool).

-define(HTTPHead,"application/x-www-form-urlencoded").

-record(apns_push,
{
  	msgid=undefined		::term(),		%%消息id
	from=undefined		::term(),		%%来源jid
	to=undefined		::term(),		%%目标jid
	msgtype=undefined	::term(),		%%消息类型
	msgbody=undefined	::term(),		%%消息体
	num=undefined		::term()		%%数量
}).

%% ====================================================================
%% API functions
%% ====================================================================
-export([send/1,start_link/0,start/0]).

-spec start_link()->_R.
start_link()->
	gen_server:start_link(?MODULE, [], []).
-spec start()->_.
start()->
	apns_sender_sup:start_child().



-spec send(Msg::term())->ok.
send(Msg)->
	%log4erl:info("apns_sender:send~p",[{Msg}]),
	{ok,Pid} = start(),
	gen_server:cast(Pid, {send,Msg}).

%% ====================================================================
%% Behavioural functions 
%% ====================================================================
-record(state, {}).

%% init/1
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:init-1">gen_server:init/1</a>
-spec init(Args :: term()) -> Result when
	Result :: {ok, State}
			| {ok, State, Timeout}
			| {ok, State, hibernate}
			| {stop, Reason :: term()}
			| ignore,
	State :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================
init([]) ->
    {ok, #state{}}.


%% handle_call/3
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_call-3">gen_server:handle_call/3</a>
-spec handle_call(Request :: term(), From :: {pid(), Tag :: term()}, State :: term()) -> Result when
	Result :: {reply, Reply, NewState}
			| {reply, Reply, NewState, Timeout}
			| {reply, Reply, NewState, hibernate}
			| {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason, Reply, NewState}
			| {stop, Reason, NewState},
	Reply :: term(),
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity,
	Reason :: term().
%% ====================================================================

handle_call(_Request, _From, State) ->
    Reply = ok,
    {reply, Reply, State}.


%% handle_cast/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_cast-2">gen_server:handle_cast/2</a>
-spec handle_cast(Request :: term(), State :: term()) -> Result when
	Result :: {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason :: term(), NewState},
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================

handle_cast({send,MessageTuple},State)->
	#apns_push{to =To,num = Num} = MessageTuple,
	[Toid|_] = string:tokens(To,"@"),
	try
		case deel_apns_msg(MessageTuple) of
			skip->
				skip;
			Msg->
				log4erl:info("toid   -----~p",[Toid]),
				Sql = io_lib:format("SELECT devicetoken FROM pre_common_member WHERE uid = ~s", [Toid]),
				case emysql_loader:do_sql(Sql) of
					[[Device]]->
						log4erl:info("apns device:~p", [Device]),
						if
							Device =:= <<>>->
								skip;
							true->
								case apns_pool:checkout(?APNS_POOL) of
									{ok,Apnsconn}->
										Res = 
										case Msg of
											{tup,Amsg,Rmsg}->
											  apns:send_message(Apnsconn, binary_to_list(Device), Amsg, Num, <<"default">>, 5000, Rmsg);
											_->
												SendMsg = 
												if
													erlang:byte_size(Msg)>= 160->
														list_to_binary(string:sub_string(Msg, 0, 160)++"...");
													true->
														list_to_binary(Msg)
												end,
												 apns:send_message(Apnsconn, binary_to_list(Device), SendMsg, Num, <<"default">>)
										end,
										log4erl:info("apns result:~p~n",[Res]);
									R1->
										log4erl:error("apns_pool:checkout error~p",[R1])
								end
						end;
					SqlR->
						log4erl:info("sql result:~p",[{Sql,SqlR,Toid}]),
						skip
				end
		end
	catch
		E:R->
			log4erl:info("apns error send:~p", [{E,R,erlang:get_stacktrace()}]),
			skip
	end,
	{stop, normal, State};

handle_cast(stop, State) ->
	{stop, normal, State};
handle_cast(_Msg, State) ->
	{noreply, State}.


%% handle_info/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_info-2">gen_server:handle_info/2</a>
-spec handle_info(Info :: timeout | term(), State :: term()) -> Result when
	Result :: {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason :: term(), NewState},
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================
handle_info(_Info, State) ->
    {noreply, State}.


%% terminate/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:terminate-2">gen_server:terminate/2</a>
-spec terminate(Reason, State :: term()) -> Any :: term() when
	Reason :: normal
			| shutdown
			| {shutdown, term()}
			| term().
%% ====================================================================
terminate(_Reason, _State) ->
    ok.


%% code_change/3
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:code_change-3">gen_server:code_change/3</a>
-spec code_change(OldVsn, State :: term(), Extra :: term()) -> Result when
	Result :: {ok, NewState :: term()} | {error, Reason :: term()},
	OldVsn :: Vsn | {down, Vsn},
	Vsn :: term().
%% ====================================================================
code_change(_OldVsn, State, _Extra) ->
    {ok, State}.


%% ====================================================================
%% Internal functions
%% ====================================================================


get_apns_str(Type,Msgtype)->
	Typestr = if
				  is_integer(Type)->
					  integer_to_list(Type);
				  true->
					  binary_to_list(Type)
			  end,
	Key = "apns_"++Msgtype++"_"++Typestr,
	log4erl:info("apns_key~p", [Key]),
	case  ets:lookup(translations, {"zh", Key}) of
  		[{_, Trans}]->
			binary_to_list(Trans);
		_->
			skip
	end.

%%推送消息格式处理
deel_apns_msg(Message)->
	#apns_push{msgtype = Msgtype, msgbody = JO } = Message,
	{ok,Type} = rfc4627:get_field(JO, "type"),
	Mark = 
		case rfc4627:get_field(JO, "mark") of
			{ok,M}->
				M;
			_->
				<<"0">>
		end,
%	log4erl:info("deel_apns_msg:~p",[Message]),
	if
		Msgtype =:= "normalchat",Mark =:= <<"0">> ->
			if
				Type =:= <<"0">>;Type =:= 0->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					{ok,ContentB} = rfc4627:get_field(JO, "content"),
					Content = binary_to_list(ContentB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
%% 							Name++BStr++Content
							io_lib:format(BStr,[Name,Content])
					end;
				Type =:= <<"1">>;Type =:= 1->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"2">>;Type =:= 2->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"4">>;Type =:= 4->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"5">>;Type =:= 5->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"6">>;Type =:= 6->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					{ok,INameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					IName = binary_to_list(INameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name,IName])
					end;
				Type =:= <<"7">>;Type =:= 7->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"8">>;Type =:= 8->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"9">>;Type =:= 9->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"10">>;Type =:= 10->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"11">>;Type =:= 11->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"12">>;Type =:= 12->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, Name)
					end;
				Type =:= <<"13">>;Type =:= 13->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"15">>;Type =:= 15->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"16">>;Type =:= 16->
					{ok,NameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;

				true->
					skip
			end;
		Msgtype =:= "groupchat",Mark =:= <<"0">> ->
			if
				Type =:= <<"0">>;Type =:= 0->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					{ok,ContentB} = rfc4627:get_field(JO, "content"),
					Content = binary_to_list(ContentB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name,Content])
					end;
				Type =:= <<"1">>;Type =:= 1->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"2">>;Type =:= 2->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"4">>;Type =:= 4->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"5">>;Type =:= 5->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"6">>;Type =:= 6->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					{ok,INameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					IName = binary_to_list(INameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name,IName])
					end;
                 		Type =:= <<"15">>;Type =:= 15->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"16">>;Type =:= 16->
					{ok,NameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				true->
					skip
			end;
		Msgtype =:= "super_groupchat",Mark =:= <<"0">> ->
			if
				Type =:= <<"1000">>;Type =:= 1000->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					{ok,NameGB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					NameG = binary_to_list(NameGB),
					{ok,ContentB} = rfc4627:get_field(JO, "content"),
					Content = binary_to_list(ContentB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name,NameG,Content])
					end;
				Type =:= <<"1001">>;Type =:= 1001->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"1002">>;Type =:= 1002->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"1004">>;Type =:= 1004->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"1005">>;Type =:= 1005->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"1006">>;Type =:= 1006->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					{ok,INameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					IName = binary_to_list(INameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name,IName])
					end;
				Type =:= <<"1013">>;Type =:= 1013->
                                        {ok,NameB} = rfc4627:get_field(JO, "username"),
                                        Name = binary_to_list(NameB),
                                        case get_apns_str(Type,Msgtype) of
                                                skip->
                                                        skip;
                                                BStr->
                                                        io_lib:format(BStr,[Name])
                                        end;
                  		Type =:= <<"1015">>;Type =:= 1015->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"1016">>;Type =:= 1016->
					{ok,NameB} = rfc4627:get_field(JO, "name"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				true->
					skip
			end;
		Msgtype =:= "system",Mark =:= <<"0">> ->
			if
				Type =:= <<"1">>;Type =:= 1 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"3">>;Type =:= 3 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"4">>;Type =:= 4 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"5">>;Type =:= 5 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"6">>;Type =:= 6 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"7">>;Type =:= 7 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"8">>;Type =:= 8 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"9">>;Type =:= 9 ->
%% 					{ok,NameB} = rfc4627:get_field(JO, "username"),
%% 					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[])
					end;
				Type =:= <<"10">>;Type =:= 10 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"11">>;Type =:= 11 ->
					{ok,NameB} = rfc4627:get_field(JO, "username"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[Name])
					end;
				Type =:= <<"12">>;Type =:= 12 ->
					{ok,NameB} = rfc4627:get_field(JO, "invitename"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"13">>;Type =:= 13 ->
					{ok,NameB} = rfc4627:get_field(JO, "invitename"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"14">>;Type =:= 14 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"15">>;Type =:= 15 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"21">>;Type =:= 21 ->
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[])
					end;
				Type =:= <<"101">>;Type =:= 101 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,Invitednameb} = rfc4627:get_field(JO, "invitename"),
					Name = binary_to_list(NameB),
					Invitedname = binary_to_list(Invitednameb),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Invitedname,Name])
					end;
				Type =:= <<"102">>;Type =:= 102 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,Beinvitednameb} = rfc4627:get_field(JO, "beinvitedname"),
					Name = binary_to_list(NameB),
					Beinvitedname = binary_to_list(Beinvitednameb),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Beinvitedname,Name])
					end;
				Type =:= <<"103">>;Type =:= 103 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,Beinvitednameb} = rfc4627:get_field(JO, "beinvitedname"),
					Name = binary_to_list(NameB),
					Beinvitedname = binary_to_list(Beinvitednameb),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Beinvitedname,Name])
					end;
				Type =:= <<"104">>;Type =:= 104 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,InvitenameB} = rfc4627:get_field(JO, "invitename"),
					Name = binary_to_list(NameB),
					Invitename = binary_to_list(InvitenameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Invitename,Name])
					end;
				Type =:= <<"105">>;Type =:= 105 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"106">>;Type =:= 106 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"113">>;Type =:= 113 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"114">>;Type =:= 114 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"115">>;Type =:= 115 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,LefttimesB} = rfc4627:get_field(JO, "lefttimes"),
					Name = binary_to_list(NameB),
					Lefttimes = binary_to_list(LefttimesB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name,Lefttimes])
					end;
				Type =:= <<"116">>;Type =:= 116 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					{ok,LefttimesB} = rfc4627:get_field(JO, "lefttimes"),
					Name = binary_to_list(NameB),
					Lefttimes = binary_to_list(LefttimesB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name,Lefttimes])
					end;
				Type =:= <<"117">>;Type =:= 117 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"118">>;Type =:= 118 ->
%% 					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
%% 					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [])
					end;
				Type =:= <<"119">>;Type =:= 119 ->
					{ok,NameB} = rfc4627:get_field(JO, "groupname"),
					Name = binary_to_list(NameB),
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr, [Name])
					end;
				Type =:= <<"120">>;Type =:= 120 ->
					case get_apns_str(Type,Msgtype) of
						skip->
							skip;
						BStr->
							io_lib:format(BStr,[])
					end;
				Type =:= <<"121">>;Type =:= 121 ->
                                        case get_apns_str(Type,Msgtype) of
                                                skip->
                                                        skip;
                                                BStr->
                                                        io_lib:format(BStr,[])
                                        end;
				Type =:= <<"122">>;Type =:= 122 ->
                                        case get_apns_str(Type,Msgtype) of
                                                skip->
                                                        skip;
                                                BStr->
                                                        io_lib:format(BStr,[])
                                        end;
				Type =:= <<"123">>;Type =:= 123 ->
                                        case get_apns_str(Type,Msgtype) of
                                                skip->
                                                        skip;
                                                BStr->
                                                        io_lib:format(BStr,[])
                                        end;
					Type =:= <<"130">>;Type =:= 130 ->
				   	{ok,RoomNumB} = rfc4627:get_field(JO, "number"),
				   	{ok,RoomName} = rfc4627:get_field(JO, "username"),
						case get_apns_str(Type,Msgtype) of
							skip->
								skip;
							BStr->
								ARe  = io_lib:format(BStr,[binary_to_list(RoomName)]),
								RRe = [{<<"roomnum">>,RoomNumB}],
								{tup,ARe,RRe}
						end;

				%		RoomNum = binary_to_list(RoomNumB),
				%		Re = {lt,{[{<<"roomnum">>,RoomNumB},{<<"anchorname">>,RoomName}]}},
				%		Re = [{<<"roomnum">>,RoomNumB},{<<"anchorname">>,RoomName}],
					%	#loc_alert{
				 %		key = ["roomnum","test"],
				%			args = [RoomNum,"test"]
				%		},
				%		{tup,Re};
			true->
					skip
			end;
		true->
			skip
	end.

